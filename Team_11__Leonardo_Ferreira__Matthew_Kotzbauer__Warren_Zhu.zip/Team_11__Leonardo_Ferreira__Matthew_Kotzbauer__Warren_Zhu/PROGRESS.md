# Progress Report — Team 11

**Team 11**: Leonardo Ferreira, Matthew Kotzbauer, Warren Zhu
**Course**: CS 1440R / 2440R, HT Kung
**Final presentation**: delivered Mon 2026-04-27, 3:42pm
**Final report deadline**: **Fri 2026-05-08, 23:59 EDT** (moved up from 5/10 by FAS Registrar mandate, see Canvas announcement 5/1)
**Last updated**: 2026-05-05

## Submission readiness (2026-05-05, end of day)

The repo is in a submittable state today, three days before the revised report deadline.

Updates since morning checkpoint:
- Eval expanded from 16 to 26 problems (10 new hand-labeled ChipBench self_contain entries)
- Re-ran routing eval on all 15 models on the 26-problem set (390 calls)
- Multi-seed (n=3) runs for the four headline models (312 additional calls), reordered the leaderboard
- Embedding-similarity router added as a comparison configuration
- Cost-and-latency analysis for all 15 models (191x cost spread; Pareto frontier is entirely Gemini Flash variants)
- Failure-mode quantification (4 modes per LLM) with stacked-bar figure
- `docs/INTEGRITY.md` documents how the benchmark resists LLM-generated problems/labels
- Report Table I now reports both single-seed and 3-seed mean with per-problem σ
- Supplement zip rebuilt to include all new JSON results, INTEGRITY.md, multi_seed/ output Headline numbers, leading figure, 3-page IEEE PDF, code supplement script, and reproducibility docs are all in place and verified.

| Submission artifact | State | Path |
|---|---|---|
| 3-page IEEE PDF | builds clean, 3 pages, all citations resolve | `report/report.pdf` |
| LaTeX source | scrubbed of LLM voice patterns | `report/report.tex` |
| Leading figure (rubric requires one) | renders pipeline + orthogonality scatter, 4 highlighted models | `report/figs/leading.{pdf,png}` |
| Code supplement zip | builder script ready, follows Canvas naming convention | `scripts/build_supplement.sh` |
| Project context | canonical state doc, linked from project CLAUDE.md | `CONTEXT.md` |
| Repo README | current with 30 IPs / 16 problems / 15 models | `README.md` |

### What was validated (and how)

| Claim | Validation |
|---|---|
| 30 IPs in corpus, all self-tests pass | Re-ran every `iverilog -g2012` self-test 2026-05-05; 30/30 PASS |
| 15 models in routing eval, 16 problems | `summary.json` keys + per-LLM `n` values verified |
| Headline 4 models F1 numbers (table I in report) | Match `summary.json` exactly, n=16 in each cell |
| Report compiles to 3 pages | `pdflatex` runs twice, exit 0, `pdfinfo` reports Pages: 3 |
| Citations resolve | No `[?]` in compiled PDF |
| Voice scrub leaves content intact | Two parallel forks edited only voice, page count unchanged |

### What was NOT validated (open risks)

| Risk | Mitigation we'd want |
|---|---|
| Single-seed numbers, run-to-run variance is real (Opus 4.7 swung 0.678→0.375 between runs) | Multi-seed (n=3) averaging, not done |
| Single annotator on the 16 gold labels | Cohen's kappa with second annotator, not done |
| Citation arXiv IDs trusted from intermediate slides, not independently verified | Spot-check before final submission |
| Team contribution split is approximate | Confirm with Leo and Warren before submitting |
| Harness end-to-end pass rate vs scratch baseline on cpu_ip is the same (1/9), report softens around this | Frame routing-quality as the contribution, do not claim end-to-end win |
| IEEE format: used `\documentclass[conference]{IEEEtran}`, not strictly verified against the latest IEEE template | Run a conference-format checker before final submission |

## Post-presentation expansion (2026-04-27, after final)

Benchmark grew after the final-presentation slot:

- **Corpus 20 → 30 IPs**: added `alu`, `multiplier`, `divider`, `bcd_counter`,
  `gray_counter`, `johnson_counter`, `up_down_counter`, `freq_divider`, `lfsr`,
  `t_flipflop`. Each ships with an Icarus self-test; all 30 pass.
- **Eval set 9 → 16 problems**: added 7 ChipBench self_contain problems
  (Prob000 mux, Prob030 RAM, Prob028 up/down counter, Prob031 Johnson counter,
  Prob023 Gray counter, Prob017 fractional freq divider, Prob032 pipeline
  multiplier). Each picked because there's a single architectural-fit IP in
  the new corpus, so routing scores have a meaningful ceiling.
- **Gold labels updated** in `eval/gold_labels.py`. The 9 cpu_ip entries are
  unchanged (so old runs remain comparable); the 7 new self_contain entries
  reference the new IPs.
- **`eval/test_routing.py` `_prompt_path`** now also looks in
  `dataset_self_contain` so problems from either set work without code
  changes.
- Re-ran routing eval on all 15 models × 16 problems; figures and
  `summary.json` regenerated.

### Routing F1 leaderboard on 16 problems (vs. 9 before)

| Rank | Model | F1 (16-prob) | F1 (9-prob, prior) | Δ |
|---|---|---|---|---|
| 1 | Gemini 2.5 Flash | 0.523 | (excl.) | — |
| 2 | GPT-5.2 | 0.467 | 0.522 | -0.055 |
| 3 | DeepSeek V3.2 | 0.441 | 0.700 | **-0.259** |
| 4 | Gemini 2.5 Flash-Lite | 0.437 | 0.555 | -0.118 |
| 5 | GPT-5.4 | 0.404 | 0.615 | -0.211 |
| 6 | Gemini 3.1 Flash-Lite Preview | 0.394 | 0.537 | -0.143 |
| 7 | Claude Opus 4.7 | 0.375 | 0.478 | -0.103 |
| 8 | Claude Haiku 4.5 | 0.349 | 0.496 | -0.147 |
| 8 | DeepSeek-R1 | 0.349 | 0.621 | **-0.272** |
| 10 | GPT-5.1 | 0.325 | 0.500 | -0.175 |
| 11 | GPT-4.1 | 0.300 | 0.533 | -0.233 |
| 12 | Claude Sonnet 4.6 | 0.262 | 0.456 | -0.194 |
| 13 | GPT-5 | 0.188 | 0.333 | -0.145 |
| 14 | Gemini 2.5 Pro | 0.188 | 0.389 | -0.201 |
| 15 | Gemini 3 Flash Preview | 0.136 | 0.300 | -0.164 |

Most models dropped 0.10–0.27 F1 going from 9 to 16 problems. The new
self_contain problems were *not* easier — they exposed routing weaknesses
that the cpu_ip set didn't.

Failure pattern: on a problem like `Prob028_up_and_down_counter`, the
planner often labels the subblock as `REUSE_IP` with `search_query="counter"`
which the keyword router resolves to `up_counter` instead of the (correct)
`up_down_counter`. The router does keyword-overlap; the corpus has many
counter variants now and the planner's queries are not specific enough to
disambiguate. **This is the bottleneck the corpus expansion surfaces** — and
it's exactly the kind of finding the original 9-problem set hid.

## What changed since the intermediate

The intermediate deck (`slides/intermediate.{md,pdf}`) framed the project as a
single-LLM harness. HT's note after the intermediate was: *turn this into a
benchmark; compare LLMs.* This presentation does that.

Concrete additions:

- **Multi-provider runner** (`eval/providers.py`): Claude CLI, OpenAI SDK,
  Bedrock (DeepSeek), Gemini REST.
- **Cross-LLM routing eval** (`eval/multi_routing.py`): runs the planner +
  router pipeline across N LLMs on the 9 cpu_ip problems, scores against the
  hand-labeled gold in `eval/gold_labels.py`. Aggregates to
  `results/multi_routing/summary.json`.
- **Cross-LLM scratch baseline** (`eval/run_multi.py`): same 15 ChipBench
  problems, single-shot Verilog gen, kept as a foil — answers "is the model
  that writes the best Verilog also the best at recognizing reusable IP?"
- **Figure pipeline** (`eval/make_figures.py`): 10 figures, all rebuilt from
  the JSON results.

## Models in the eval (14 total)

| Provider | Model | API path |
|---|---|---|
| Anthropic | Claude Opus 4.7 | `claude` CLI |
| Anthropic | Claude Sonnet 4.6 | `claude` CLI |
| Anthropic | Claude Haiku 4.5 | `claude` CLI |
| OpenAI | GPT-5.4 | OpenAI SDK |
| OpenAI | GPT-5.2 | OpenAI SDK |
| OpenAI | GPT-5.1 | OpenAI SDK |
| OpenAI | GPT-5 | OpenAI SDK |
| OpenAI | GPT-4.1 | OpenAI SDK |
| AWS Bedrock | DeepSeek-R1 | `bedrock-runtime` (us-east-1) |
| AWS Bedrock | DeepSeek V3.2 | `bedrock-runtime` (us-east-1) |
| Google | Gemini 2.5 Pro | REST |
| Google | Gemini 2.5 Flash-Lite | REST |
| Google | Gemini 3 Flash Preview | REST |
| Google | Gemini 3.1 Flash-Lite Preview | REST |

Same planner prompt, same router (deterministic, MCP-backed), same 20-IP
corpus, same 9 cpu_ip problems. No few-shot examples. Gemini 2.5 Flash,
Gemini 3 Pro Preview, and Gemini 3.1 Pro Preview returned mostly 503s and
are excluded.

## Headline results

### Routing F1 (planner + router vs hand-labeled gold)

Top 5 by mean F1 across 9 problems (from `results/multi_routing/summary.json`):

| Rank | Model | Precision | Recall | F1 | Kind agreement |
|---|---|---|---|---|---|
| 1 | DeepSeek V3.2 | 0.741 | 0.674 | **0.700** | 0.846 |
| 2 | DeepSeek-R1 | 0.722 | 0.578 | **0.621** | 0.741 |
| 3 | GPT-5.4 | 0.722 | 0.600 | **0.615** | 0.769 |
| 4 | GPT-4.1 | 0.556 | 0.519 | **0.533** | 0.806 |
| 5 | GPT-5.2 | 0.574 | 0.489 | **0.522** | 0.796 |

Bottom 3:

| Rank | Model | F1 | What went wrong |
|---|---|---|---|
| 10 | GPT-5 | 0.333 | under-decomposes (avg 1.0 subblocks/problem; never triggers the router) |
| 9 | Sonnet 4.6 | 0.456 | mis-routes: high subblock count, picks wrong IP |
| 8 | Opus 4.7 | 0.478 | high run-to-run variance — earlier runs got 0.678 |

### Scratch baseline (foil — `not just synthesis`)

Top scratch coders (cpu_ip pass rate):

| Model | not_self_contain | cpu_ip |
|---|---|---|
| Claude Sonnet 4.6 | 3/6 = 50% | 1/9 = 11% |
| Claude Haiku 4.5 | 3/6 = 50% | 1/9 = 11% |
| GPT-5.4 | 1/6 = 17% | 1/9 = 11% |
| All others | ≤ 2/6 | 1/9 |

Scratch pass rates are low and very flat across LLMs on cpu_ip. The
routing axis spreads models out far more — that's the headline.

## Figures (in `slides/figs/`)

| File | What it shows |
|---|---|
| `routing_f1.pdf` | P / R / F1 grouped bars per LLM, sorted by F1 |
| `routing_heatmap.pdf` | per-(LLM, problem) F1 heatmap |
| `provider_rollup.pdf` | mean F1 by provider family (OpenAI / Anthropic / Bedrock) |
| `kind_vs_f1.pdf` | scatter: kind agreement vs F1 (knowing *when* to reuse ≠ picking the right IP) |
| `decomposition.pdf` | avg subblocks + REUSE_IP % per LLM |
| `problem_difficulty.pdf` | per-problem mean F1 across 10 LLMs (which problems are hardest) |
| `ip_frequency.pdf` | which IPs the corpus actually surfaces; green = also in gold, red = mis-routes |
| `latency.pdf` | seconds-per-planner-call by LLM |
| `scratch_baseline.pdf` | scratch-Verilog pass rate by LLM, both datasets |
| `routing_vs_scratch.pdf` | scatter: routing F1 vs scratch pass rate (orthogonal axes) |

## What we can claim cleanly

1. **IP-reuse skill is its own axis.** Across 10 LLMs, routing F1 ranges from
   0.33 to 0.70 while scratch pass rate on cpu_ip is flat at 1/9 for most.
   A scratch-only benchmark would call these models indistinguishable.
2. **The planner is the bottleneck, not the codegen.** Same router on the
   same corpus; variance lives in subblock decomposition and the
   `search_query` field. GPT-5 produces 1 subblock on average and never
   triggers the router.
3. **Provider family doesn't predict the winner.** Bedrock/DeepSeek tops the
   board on routing; Anthropic tops scratch. They're solving different tasks.
4. **A 20-IP corpus is enough to score 9 cpu_ip problems meaningfully.** No
   evidence yet that we need a 200-IP corpus to differentiate models.

## What we are not claiming

- Not that the harness end-to-end beats single-shot codegen on cpu_ip. It
  doesn't (1/9 vs 1/9). That's a separate, slower fix.
- Not SOTA on any existing benchmark. We re-eval on ChipBench.
- Not that any model is "better" overall — only that *routing* and *scratch*
  are independent axes.

## Caveats

- **Run-to-run variance**: temperature 0 still gives noticeable variance on
  some Anthropic models (Opus 4.7: 0.678 → 0.478 between two runs). One run
  of each model in the headline numbers; needs averaging across N seeds.
- **Gold labels**: 9 hand-labeled entries by one annotator (Matt). Recall
  is only as good as the gold set. Some problems have empty gold (`Prob001
  controller`: no IP fits in the 20-corpus) — those score 1.0 vacuously when
  the model also picks nothing.
- **Gemini scratch**: 400-class API errors during the scratch sweep on most
  problems; routing eval ran clean. Gemini scratch numbers excluded from
  comparison.

## Repo layout (relevant subset)

```
eval/
  providers.py          # multi-provider LLM adapters
  multi_routing.py      # cross-LLM routing eval driver
  run_multi.py          # cross-LLM scratch baseline driver
  make_figures.py       # all 10 figures from results JSON
  gold_labels.py        # hand-labeled gold for cpu_ip
  test_routing.py       # scoring (P/R/KA against gold)
results/
  multi_routing/        # per-LLM routing JSON + summary.json
  multi/                # per-LLM scratch JSON
slides/
  intermediate.{md,pdf} # original presentation
  final.tex             # final presentation source
  figs/                 # all PDF/PNG figures
```

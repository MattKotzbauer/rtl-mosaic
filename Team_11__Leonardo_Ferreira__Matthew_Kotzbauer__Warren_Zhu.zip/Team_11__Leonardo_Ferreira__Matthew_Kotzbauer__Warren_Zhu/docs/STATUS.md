# STATUS — internal context doc (gitignored)

> This file is private to us. Drop it into Claude / any conversation as
> context to skip re-explaining the project. Update when state changes.
> Last updated: **2026-04-19** (night before intermediate presentation)

## TL;DR

**Course**: CS 1440R, Harvard, Spring 2026, instructor HT Kung.
**Team 11**: Leonardo Ferreira · Matt Kotzbauer · Warren Zhu.
**Repo**: https://github.com/MattKotzbauer/rtl-mosaic (public).
**Local**: `/home/matt/school/1440r/project/silicon-mind-harness/`.
**Intermediate presentation**: 2026-04-20 (tomorrow). Final: ~1 week after.

## Project framing

Build a **system-level RTL design harness** on top of SiliconMind-V1. Take a
chip-design spec → decompose into subblocks → for each subblock, decide
**REUSE_IP** (pull from a curated corpus via MCP) or **GENERATE** (LLM
codegen) → integrate → verify with Icarus Verilog.

This came from a 2026-04-13 meeting with HT, who specifically asked for:
- a harness that breaks down complex tasks
- LLM codegen for bespoke pieces, off-the-shelf components otherwise
- exposure to "~50 unique IP modules"
- agent should access IP via MCP (not raw source)

## What we are NOT claiming

- Not training a Verilog model. We use Claude Sonnet 4.6 as the codegen LLM.
- Not beating SiliconMind on its own benchmark (single-module Verilog).
- Not claiming SOTA pass rates on VerilogEval/RTLLM (~94% from agentic GPT-4
  on those is the bar; we'll be well below).
- Not contributing a new training-data pipeline.

## What we ARE claiming

The **system-level reuse pattern** is worth its complexity vs naked codegen.
Concretely:
1. Decomposition + IP-reuse beats single-shot LLM on hierarchical and CPU-IP
   problems (where single-shot crashes).
2. The MCP boundary is the right abstraction for IP access — it keeps the
   agent's context budget sane and makes IP licensing/auditing trivial.
3. A modest corpus (~20 IPs) targeted at the benchmark's actual decomposition
   needs covers a meaningful fraction of subblocks.

## Differentiation matrix

| Axis | SiliconMind-V1 | SOTA agentic (GPT-4 + iter) | Us |
|---|---|---|---|
| Layer | trains small open model on 36K verified data | wraps big model in iterate-on-testbench | wraps big model in **decompose + reuse** loop |
| Output unit | one module | one module | a *system* of modules |
| Verifier in loop | training-time | inference-time | inference-time |
| Novel piece | training-data pipeline | tight test-feedback | **IP corpus + MCP boundary** |
| Open weights? | yes (Olmo-3-7B based) | no | n/a (we use Claude) |

## What we're testing (eval design)

**Primary metric**: pass rate on ChipBench `not_self_contain` (6 problems) +
`cpu_ip` (9 problems) = 15 problems. Same Icarus-testbench-mismatch metric as
SiliconMind. Compare:

- **Baseline**: single-shot Claude Sonnet 4.6, no harness, no reuse
- **Ours**: full harness (planner → router → integrator → verifier)

Today's baseline: **4/15 = 27%** (3/6 hierarchical, 1/9 cpu_ip). Goal for
final: **≥ 60%**.

**Secondary metrics** (per `eval/metrics.py`):
- `n_llm_calls / problem` — cost proxy
- `reuse_ratio = loc_reused / (loc_reused + loc_generated)`
- `precision/recall` of planner's IP-routing decisions vs hand-labeled gold
  (per `eval/test_routing.py`)

## State of the codebase (2026-04-19 night)

| Component | Status | File |
|---|---|---|
| ChipBench dataset vendored | ✓ | `ChipBench/` (in parent dir, not in repo) |
| Baseline runner | ✓ | `eval/run_baseline.py` |
| Baseline numbers measured | ✓ | `results/baseline/results.json` (27%) |
| MCP server | ✓ working, 8/8 tests | `mcp/server.py`, `mcp/test_mcp.py` |
| MCP corpus (5 IPs, demo) | ✓ | `mcp/corpus/{catalog.json, modules/}` |
| MCP corpus (20 IPs, real) | ⏳ in progress (subagent) | adding 15 new |
| Per-IP self-tests | ⏳ in progress (subagent) | `mcp/corpus/tests/` |
| Planner / codegen / router / integrator | ✓ | `harness/*.py` |
| End-to-end harness CLI | ✓ ran on Prob004 + Prob006 | `harness/run_harness.py` |
| Eval metrics module | ✓ | `eval/metrics.py` |
| Routing eval (gold-label tests) | ⏳ in progress (subagent) | `eval/{gold_labels.py, test_routing.py}` |
| Harness sweep on cpu_ip set | TODO (after IPs land) | will populate `results/harness/` |
| Slide deck (16 slides + PDF) | ✓ | `slides/intermediate.{md,pdf}` |
| IP corpus plan (52-module shortlist) | ✓ | `docs/IP_CORPUS_PLAN.md` |
| Architecture doc | ✓ | `docs/ARCHITECTURE.md` |
| README | ✓ | `README.md` |

## End-to-end harness demo results so far

- **Prob004 sync FIFO**: planner → 4 subblocks (3 REUSE_IP, 1 GENERATE).
  Compiled clean. Sim: 232/327 mismatches on `rdata` (`wfull`/`rempty`
  correct). Failure is in LLM-stitched TopModule wiring, not decomposition.
- **Prob006 CPU top**: planner → 5 subblocks (2 REUSE_IP, 3 GENERATE).
  Decomposition reasonable. Compile failed: LLM emitted ``` `WORD_SIZE ```
  macro references. Fixable by adapter-DSL or better integrator prompt.

## Open design questions (raise these in tomorrow's Q&A)

1. **Pass-rate target for final**: 60% reasonable, or ambitious / conservative?
2. **Planner architecture**: keep prompt-only (Strategy 4) or fine-tune
   (Strategy 2)? Fine-tuning would mean small SiliconMind-style training set.
3. **MCP boundary**: enough for the security/audit angle, or pull it out as
   its own contribution?
4. **Corpus depth vs breadth**: 20 deep-tested vs 200 shallow vs 50 medium?
5. **Test-feedback loop**: when (not if) we add this, do we cap retries at N,
   or run until pass / budget exhausted?

## Splits (proposed, may shift)

- **Matt**: MCP server + IP corpus + ingestion pipeline + this status doc
- **Warren**: planner / decomposer / integrator + adapter-DSL for TopModule
- **Leo**: eval harness + metrics + test-feedback loop + slide deck

## Decisions logged

- **2026-04-13**: HT meeting → project scope locked (decomp + IP reuse).
- **2026-04-19 evening**: repo `silicon-mind-harness` renamed to `rtl-mosaic`
  (HT-team optics — don't sound like we're copying SiliconMind), made public.
- **2026-04-19**: corpus target moved from "5 demo / 50 planned" to "20 real,
  tested" before intermediate. Trade-off: less corpus depth, more rigor.
- **2026-04-19**: chose Marp markdown for slides (renders to PDF, lives in
  repo, easy to git-diff vs Google Slides).

## Things to NOT do

- Don't try to retrain SiliconMind itself; we don't have the data pipeline.
- Don't add UART/SPI/AXI to the corpus right now — ChipBench doesn't need
  them. Stay focused on what the benchmark requires.
- Don't claim the harness is "secure" — the MCP boundary is a clean *layer*
  for security, not a security claim.

## Useful paths

- ChipBench dataset:
  `/home/matt/school/1440r/project/ChipBench/Verilog Gen/dataset_{self_contain,not_self_contain,cpu_ip}/`
- Baseline results:
  `results/baseline/results.json`
- Harness traces:
  `results/harness/<prob>_trace.json`
- Slide source: `slides/intermediate.md`
- Slide PDF: `slides/intermediate.pdf`

## Useful commands

```bash
# baseline (all 15 problems)
python eval/run_baseline.py --datasets not_self_contain cpu_ip --workers 4

# harness on one problem
python -m harness.run_harness <prompt> <ref> <test>

# MCP smoke tests
python -m pytest mcp/test_mcp.py -v

# render slides
cd slides && npx --yes @marp-team/marp-cli@latest intermediate.md --pdf --allow-local-files
```

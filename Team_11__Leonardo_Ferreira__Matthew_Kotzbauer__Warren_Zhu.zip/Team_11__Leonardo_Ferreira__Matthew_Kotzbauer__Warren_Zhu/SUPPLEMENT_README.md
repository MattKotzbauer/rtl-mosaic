# Team 11 Final Report Supplement — rtl-mosaic

Read these in order:
1. `report/report.pdf` — the 3-page IEEE submission
2. `CONTEXT.md` — full project context, current state, open TODOs
3. `README.md` — repo overview + how to reproduce
4. `PROGRESS.md` — detailed status log + delta tables across eval revisions

To reproduce the headline numbers:
```bash
cd <package>
source ~/school/.env  # OPENAI_API_KEY, GEMINI_API_KEY, AWS creds
python3 eval/multi_routing.py --workers 16
python3 eval/make_figures.py
```

Layout:
- `eval/`     multi-LLM routing eval, scratch baseline, gold labels, figure pipeline
- `harness/`  planner + IP router + codegen + integrator
- `mcp/`      IP-search MCP server + 30-IP corpus + per-IP self-tests
- `slides/`   Beamer source + PDF + figures + spoken script (presentation 2026-04-27)
- `report/`   IEEE 2-col final report source + figures
- `results/`  Frozen JSON snapshot of headline numbers
